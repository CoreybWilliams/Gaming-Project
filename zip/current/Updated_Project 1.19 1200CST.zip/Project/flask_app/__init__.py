from flask import Flask

app = Flask(__name__)
app.secret_key = 'a;wpitua;oi gjae;ogihaeroi;ghae;roighse;oigha;dogjh'